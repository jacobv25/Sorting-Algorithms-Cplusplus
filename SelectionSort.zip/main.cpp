#include <iostream>
using namespace std;

void selectionSort(int array[], int size) {
	 int temp;
   int minIndex;
   for(int i = 0; i<size-1; i++) {
      minIndex = i;   
      for(int j = i+1; j<size; j++)
         if(array[j] < array[minIndex])
            minIndex = j;
		 				temp = array[i];
						array[i] = array[minIndex];
						array[minIndex] = temp;
   }
}
int main() {
   int size;
   cout << "Enter the number of elements: ";
   cin >> size;
   int arr[size];
   cout << "Enter elements:" << endl;
   for(int i = 0; i<size; i++) {
      cin >> arr[i];
   }

   selectionSort(arr, size);
   cout << "Array after using Selection Sort: ";
   for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;
}