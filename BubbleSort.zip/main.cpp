#include<iostream>
#include <math.h>
using namespace std;

void bubbleSort(int arr[], int size) {
		int temp;
    for(int i=0; i< size; i++) {
        for (int j = 0; j < size; j++) {
            if(arr[j] > arr[i]) {
							temp = arr[i];
							arr[i] = arr[j];
							arr[j] = temp;
            }
        }
    }
}

int main()
{
    int val;
    int size;

    cout<<"What is the size of the array?"<<endl;
    cin >> size;
    int arr[size];
    for(int i=0; i < size; i++) {
        cout << "Please enter val: ";
        cin >> val;
        arr[i] = val;
    }

    bubbleSort(arr, size);
	
    cout<<"Sorted array using bubblesort: \n";
    for (int i = 0; i < size; i++)
        cout << arr[i] << " ";
    cout << endl;
    return 0;
}